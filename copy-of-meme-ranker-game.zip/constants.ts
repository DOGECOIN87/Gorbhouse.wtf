
import { Meme } from './types';

export const K_FACTOR = 32;
export const INITIAL_RATING = 1200;

const MEME_URLS: string[] = [
  "https://i.memedepot.com/gorbhouse/0.webp",
  "https://i.memedepot.com/gorbhouse/1.webp",
  "https://i.memedepot.com/gorbhouse/2.webp",
  "https://i.memedepot.com/gorbhouse/3.webp",
  "https://i.memedepot.com/gorbhouse/4.webp",
  "https://i.memedepot.com/gorbhouse/5.webp",
  "https://i.memedepot.com/gorbhouse/6.webp",
  "https://i.memedepot.com/gorbhouse/7.webp",
  "https://i.memedepot.com/gorbhouse/8.webp",
  "https://i.memedepot.com/gorbhouse/9.webp",
  "https://i.memedepot.com/gorbhouse/10.webp",
  "https://i.memedepot.com/gorbhouse/11.webp",
  "https://i.memedepot.com/gorbhouse/12.webp",
  "https://i.memedepot.com/gorbhouse/13.webp",
  "https://i.memedepot.com/gorbhouse/14.webp",
  "https://i.memedepot.com/gorbhouse/15.webp",
  "https://i.memedepot.com/gorbhouse/16.webp",
  "https://i.memedepot.com/gorbhouse/17.webp",
  "https://i.memedepot.com/gorbhouse/18.webp",
  "https://i.memedepot.com/gorbhouse/19.webp",
  "https://i.memedepot.com/gorbhouse/20.webp",
  "https://i.memedepot.com/gorbhouse/21.webp",
  "https://i.memedepot.com/gorbhouse/22.webp",
  "https://i.memedepot.com/gorbhouse/23.webp",
  "https://i.memedepot.com/gorbhouse/24.webp",
  "https://i.memedepot.com/gorbhouse/25.webp",
  "https://i.memedepot.com/gorbhouse/26.webp",
  "https://i.memedepot.com/gorbhouse/27.webp",
  "https://i.memedepot.com/gorbhouse/28.webp",
  "https://i.memedepot.com/gorbhouse/29.webp",
];

export const MEME_DATA: Meme[] = MEME_URLS.map((url, index) => ({
  id: index,
  url: url,
  rating: INITIAL_RATING,
}));
