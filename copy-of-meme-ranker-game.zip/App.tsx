
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Meme } from './types';
import { MEME_DATA } from './constants';
import { updateRatings } from './services/eloService';
import MemeCard from './components/MemeCard';
import Leaderboard from './components/Leaderboard';

const App: React.FC = () => {
  const [memes, setMemes] = useState<Meme[]>(MEME_DATA);
  const [currentPair, setCurrentPair] = useState<[number, number] | null>(null);
  const [isVoting, setIsVoting] = useState(false);
  const [votedFor, setVotedFor] = useState<number | null>(null); // To animate winner/loser

  const selectNewPair = useCallback(() => {
    const totalMemes = memes.length;
    if (totalMemes < 2) {
      setCurrentPair(null);
      return;
    }

    let index1 = Math.floor(Math.random() * totalMemes);
    let index2 = Math.floor(Math.random() * totalMemes);

    while (index1 === index2) {
      index2 = Math.floor(Math.random() * totalMemes);
    }

    setCurrentPair([index1, index2]);
    setIsVoting(false);
    setVotedFor(null);
  }, [memes.length]);

  useEffect(() => {
    selectNewPair();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleVote = useCallback((winnerIndex: number, loserIndex: number) => {
    if (isVoting) return; // Prevent multiple votes
    setIsVoting(true);
    setVotedFor(winnerIndex); // Trigger animation

    const winner = memes[winnerIndex];
    const loser = memes[loserIndex];

    const { newWinnerRating, newLoserRating } = updateRatings(winner.rating, loser.rating);

    const updatedMemes = memes.map((meme, index) => {
      if (index === winnerIndex) {
        return { ...meme, rating: newWinnerRating };
      }
      if (index === loserIndex) {
        return { ...meme, rating: newLoserRating };
      }
      return meme;
    });

    setMemes(updatedMemes);
    setTimeout(() => {
      selectNewPair();
    }, 800); // Wait for animation before showing new pair
  }, [memes, selectNewPair, isVoting]);

  const sortedMemes = useMemo(() => {
    return [...memes].sort((a, b) => b.rating - a.rating);
  }, [memes]);

  const meme1 = currentPair ? memes[currentPair[0]] : null;
  const meme2 = currentPair ? memes[currentPair[1]] : null;

  const getVoteState = (memeIndex: number): 'winner' | 'loser' | null => {
    if (!votedFor) return null;
    return votedFor === memeIndex ? 'winner' : 'loser';
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans flex flex-col p-4 sm:p-6 lg:p-8">
      <header className="text-center mb-8">
        <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
          Meme Ranker
        </h1>
        <p className="text-gray-400 mt-2 text-lg">Which meme reigns supreme? You decide!</p>
      </header>

      <main className="flex-grow flex flex-col lg:flex-row gap-8">
        <div className="lg:w-2/3 flex flex-col items-center justify-center p-6 bg-gray-800/50 rounded-2xl shadow-2xl shadow-purple-500/10">
          <h2 className="text-2xl sm:text-3xl font-semibold mb-6">Click your favorite meme</h2>
          {meme1 && meme2 && currentPair ? (
            <div className="w-full flex flex-col md:flex-row items-center justify-around gap-4 md:gap-8">
              <MemeCard
                key={meme1.id}
                meme={meme1}
                onClick={() => handleVote(currentPair[0], currentPair[1])}
                disabled={isVoting}
                voteState={getVoteState(currentPair[0])}
              />
              <span className="text-4xl font-bold text-purple-400 my-4 md:my-0">VS</span>
              <MemeCard
                key={meme2.id}
                meme={meme2}
                onClick={() => handleVote(currentPair[1], currentPair[0])}
                disabled={isVoting}
                voteState={getVoteState(currentPair[1])}
              />
            </div>
          ) : (
            <div className="flex items-center justify-center h-64">
              <p className="text-xl text-gray-500">Loading memes...</p>
            </div>
          )}
        </div>

        <div className="lg:w-1/3 p-6 bg-gray-800/50 rounded-2xl shadow-2xl shadow-pink-500/10">
          <Leaderboard memes={sortedMemes} />
        </div>
      </main>

      <footer className="text-center mt-8 py-4 text-gray-500">
        <p>Built with React, TypeScript, and Tailwind CSS.</p>
      </footer>
    </div>
  );
};

export default App;
