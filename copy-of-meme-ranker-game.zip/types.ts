
export interface Meme {
  id: number;
  url: string;
  rating: number;
}
