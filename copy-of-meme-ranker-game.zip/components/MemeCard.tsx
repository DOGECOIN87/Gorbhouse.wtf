import React from 'react';
import { Meme } from '../types';

interface MemeCardProps {
  meme: Meme;
  onClick: () => void;
  disabled: boolean;
  voteState?: 'winner' | 'loser' | null;
}

const MemeCard: React.FC<MemeCardProps> = ({ meme, onClick, disabled, voteState }) => {
  const getDynamicClasses = () => {
    if (voteState === 'winner') {
      return 'scale-105 shadow-2xl shadow-green-500/50 ring-4 ring-green-500 z-10';
    }
    if (voteState === 'loser') {
      return 'scale-95 opacity-40';
    }
    // Default state when there is no vote yet (voteState is null).
    // This ensures a consistent starting size for each round.
    return 'scale-100 hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/50';
  };

  const cardClasses = `
    relative w-full max-w-sm aspect-square bg-gray-700 rounded-lg overflow-hidden
    shadow-lg transform transition-all duration-300
    ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}
    ${getDynamicClasses()}
  `;

  return (
    <div
      className={cardClasses}
      onClick={!disabled ? onClick : undefined}
      role="button"
      tabIndex={disabled ? -1 : 0}
      aria-label={`Vote for meme ${meme.id}`}
    >
      <img
        src={meme.url}
        alt={`Meme ${meme.id}`}
        className="w-full h-full object-contain"
        loading="lazy"
      />
      <div className="absolute inset-0 bg-black opacity-0 hover:opacity-20 transition-opacity duration-300"></div>
    </div>
  );
};

export default MemeCard;