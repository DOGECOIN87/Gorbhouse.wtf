
import React from 'react';
import { Meme } from '../types';
import { Trophy } from './Icons';

interface LeaderboardProps {
  memes: Meme[];
}

const Leaderboard: React.FC<LeaderboardProps> = ({ memes }) => {
  const getRankColor = (rank: number) => {
    switch (rank) {
      case 0: return 'text-yellow-400';
      case 1: return 'text-gray-300';
      case 2: return 'text-yellow-600';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="flex flex-col h-full">
      <h2 className="text-3xl font-bold text-center mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
        Leaderboard
      </h2>
      <div className="flex-grow overflow-y-auto pr-2">
        <ul className="space-y-3">
          {memes.map((meme, index) => (
            <li
              key={meme.id}
              className="flex items-center p-3 bg-gray-800 rounded-lg shadow-md transition-transform duration-200 hover:scale-102 hover:bg-gray-700/50"
            >
              <div className={`w-10 text-xl font-bold flex-shrink-0 ${getRankColor(index)} flex items-center justify-center`}>
                {index < 3 ? <Trophy className="w-6 h-6" /> : `#${index + 1}`}
              </div>
              <img
                src={meme.url}
                alt={`Meme ${meme.id}`}
                className="w-16 h-16 object-contain rounded-md mx-4 bg-gray-900"
                loading="lazy"
              />
              <div className="flex-grow text-right">
                <span className="font-semibold text-lg text-purple-300">{meme.rating}</span>
                <p className="text-sm text-gray-500">Elo</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Leaderboard;
