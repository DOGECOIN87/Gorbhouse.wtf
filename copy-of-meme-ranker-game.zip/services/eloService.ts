
import { K_FACTOR } from '../constants';

/**
 * Calculates the expected score of a player in a match.
 * @param playerRating The rating of the player.
 * @param opponentRating The rating of the opponent.
 * @returns The expected score (probability of winning) for the player.
 */
const calculateExpectedScore = (playerRating: number, opponentRating: number): number => {
  return 1 / (1 + Math.pow(10, (opponentRating - playerRating) / 400));
};

/**
 * Updates the ratings of two players based on the match outcome.
 * @param winnerRating The current rating of the winner.
 * @param loserRating The current rating of the loser.
 * @returns An object with the new ratings for the winner and loser.
 */
export const updateRatings = (
  winnerRating: number,
  loserRating: number
): { newWinnerRating: number; newLoserRating: number } => {
  const expectedWinnerScore = calculateExpectedScore(winnerRating, loserRating);
  const expectedLoserScore = calculateExpectedScore(loserRating, winnerRating);

  const newWinnerRating = Math.round(winnerRating + K_FACTOR * (1 - expectedWinnerScore));
  const newLoserRating = Math.round(loserRating + K_FACTOR * (0 - expectedLoserScore));

  return { newWinnerRating, newLoserRating };
};
