
import React, { useState, useCallback } from 'react';
import AudiusPlayer from './components/AudiusPlayer';
import { DEFAULT_HANDLE } from './constants';

const App: React.FC = () => {
  const [artistHandle, setArtistHandle] = useState<string>(DEFAULT_HANDLE);
  const [inputValue, setInputValue] = useState<string>(DEFAULT_HANDLE);

  const handleSearch = useCallback(() => {
    if (inputValue.trim()) {
      setArtistHandle(inputValue.trim());
    }
  }, [inputValue]);

  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900/40 to-gray-900 text-white flex flex-col items-center justify-center p-4 font-sans">
      <div className="w-full max-w-md mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white">
            Audius Player
          </h1>
          <p className="text-purple-300 mt-2">
            Stream music directly from Audius artists.
          </p>
        </header>

        <div className="mb-6">
          <div className="flex rounded-lg shadow-lg bg-white/5">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Enter artist handle (e.g., MATTRICKBEATS)"
              className="flex-grow bg-transparent px-4 py-3 text-white placeholder-gray-400 focus:outline-none"
            />
            <button
              onClick={handleSearch}
              className="bg-purple-600 hover:bg-purple-500 transition-colors duration-300 text-white font-semibold px-5 py-3 rounded-r-lg"
            >
              Search
            </button>
          </div>
        </div>

        <main>
          <AudiusPlayer key={artistHandle} artistHandle={artistHandle} />
        </main>
        
        <footer className="text-center mt-8 text-xs text-gray-500">
            <p>This is an unofficial player for the Audius platform.</p>
            <p>Tipping functionality is for demonstration purposes only.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
