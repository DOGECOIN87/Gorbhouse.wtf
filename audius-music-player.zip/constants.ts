
export const APP_NAME = 'AudiusPlayerDemo';
export const DEFAULT_HANDLE = 'MATTRICKBEATS';
